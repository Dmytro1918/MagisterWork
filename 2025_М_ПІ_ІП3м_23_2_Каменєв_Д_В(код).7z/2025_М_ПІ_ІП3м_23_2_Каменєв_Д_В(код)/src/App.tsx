// src/App.tsx
import React, { useState, useEffect, useRef } from 'react';
import { usePQMComponent, logMetrics } from './pqm';

// Метрики для обычного React
const standardMetrics: Record<string, { renderTime: number; renderCount: number; memoryUsed: number }> = {};
const isMemoryAvailable = !!performance.memory;

// Форма регистрации
const RegistrationForm: React.FC<{ onSubmit: (data: { name: string; email: string; password: string }) => void }> = ({ onSubmit }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ name, email, password });
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
      <div>
        <label>Name: </label>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
      </div>
      <div>
        <label>Email: </label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div>
        <label>Password: </label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      <button type="submit">Register</button>
    </form>
  );
};

// Компонент с PQM
const HeavyComponentPQM: React.FC<{ data: { name: string; email: string; password: string } }> = ({ data }) => {
  const ref = usePQMComponent('heavy-pqm', 10, () => {
    console.log(`Rendering HeavyComponentPQM with data: ${JSON.stringify(data)}`);
  });

  const start = performance.now();
  const largeArray = new Array(1000000).fill(Math.random());
  while (performance.now() - start < 5) {}
  return <section ref={ref}>Heavy PQM: {data.name} (Array size: {largeArray.length})</section>;
};

// Компонент без PQM
const HeavyComponentStandard: React.FC<{ data: { name: string; email: string; password: string } }> = ({ data }) => {
  const renderCount = useRef(0);
  renderCount.current += 1;

  const start = performance.now();
  const largeArray = new Array(1000000).fill(Math.random());
  while (performance.now() - start < 5) {}
  const renderTime = performance.now() - start;
  const memoryUsed = isMemoryAvailable ? performance.memory!.usedJSHeapSize / 1024 / 1024 : 0;

  useEffect(() => {
    standardMetrics['heavy-standard'] = {
      renderTime,
      renderCount: renderCount.current,
      memoryUsed: memoryUsed > 0 ? memoryUsed : 0,
    };
    console.log(`[Standard Debug] heavy-standard - Memory Used: ${memoryUsed} MB`);
  });

  console.log(`Rendering HeavyComponentStandard with data: ${JSON.stringify(data)}`);
  return <section>Heavy Standard: {data.name} (Array size: {largeArray.length})</section>;
};

// Низкоприоритетный компонент с PQM
const LowPriorityComponentPQM: React.FC<{ data: { name: string; email: string; password: string } }> = ({ data }) => {
  const ref = usePQMComponent('low-pqm', 80, () => {
    console.log(`Rendering LowPriorityComponentPQM with data: ${JSON.stringify(data)}`);
  });

  const start = performance.now();
  const smallArray = new Array(500000).fill(Math.random());
  while (performance.now() - start < 2) {}
  return <section ref={ref}>Low Priority PQM: {data.email} (Array size: {smallArray.length})</section>;
};

// Низкоприоритетный компонент без PQM
const LowPriorityComponentStandard: React.FC<{ data: { name: string; email: string; password: string } }> = ({ data }) => {
  const renderCount = useRef(0);
  renderCount.current += 1;

  const start = performance.now();
  const smallArray = new Array(500000).fill(Math.random());
  while (performance.now() - start < 2) {}
  const renderTime = performance.now() - start;
  const memoryUsed = isMemoryAvailable ? performance.memory!.usedJSHeapSize / 1024 / 1024 : 0;

  useEffect(() => {
    standardMetrics['low-standard'] = {
      renderTime,
      renderCount: renderCount.current,
      memoryUsed: memoryUsed > 0 ? memoryUsed : 0,
    };
    console.log(`[Standard Debug] low-standard - Memory Used: ${memoryUsed} MB`);
  });

  console.log(`Rendering LowPriorityComponentStandard with data: ${JSON.stringify(data)}`);
  return <section>Low Priority Standard: {data.email} (Array size: {smallArray.length})</section>;
};

function App() {
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });

  const handleSubmit = (data: { name: string; email: string; password: string }) => {
    setFormData(data);
  };

  useEffect(() => {
    logMetrics('MB');
    console.log('[Standard Metrics (MB)]', standardMetrics);
  }, [formData]);

  return (
    <div>
      <h1>Single Form Test</h1>
      <RegistrationForm onSubmit={handleSubmit} />
      <HeavyComponentPQM data={formData} />
      <HeavyComponentStandard data={formData} />
      <LowPriorityComponentPQM data={formData} />
      <LowPriorityComponentStandard data={formData} />
    </div>
  );
}

export default App;