import React, { useState, useEffect, useRef, memo } from 'react';
import { usePQMComponent, logMetrics } from './pqm';

// Объекты для хранения метрик
const standardMetrics: Record<string, { renderTime: number; renderCount: number; memoryUsed: number }> = {};
const pqmMetrics: Record<string, { renderTime: number; renderCount: number; memoryUsed: number }> = {};
const isMemoryAvailable = !!performance.memory;

const RegistrationForm: React.FC<{ id: number; onSubmit: (data: { name: string; email: string; password: string }, id: number) => void }> = ({ id, onSubmit }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ name, email, password }, id);
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: '10px', border: '1px solid #ccc', padding: '10px' }}>
      <div>
        <label>Form {id} - Name: </label>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
      </div>
      <div>
        <label>Email: </label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div>
        <label>Password: </label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      <button type="submit">Register (Form {id})</button>
    </form>
  );
};

// Компонент с PQM
const HeavyComponentPQM = memo(
  ({ data, formId }: { data: { name: string; email: string; password: string }; formId: number }) => {
    const renderCount = useRef(0);
    renderCount.current += 1;

    const ref = usePQMComponent(`heavy-pqm-${formId}`, 10, () => {
      // Этот коллбэк может использоваться для других целей, но метрики мы перенесём ниже
    });

    const start = performance.now();
    const largeArray = new Array(1000000).fill(Math.random());
    while (performance.now() - start < 5) {}
    const renderTime = performance.now() - start;
    const memoryUsed = isMemoryAvailable ? performance.memory!.usedJSHeapSize / 1024 / 1024 : 0;

    // Сохраняем метрики для каждого рендера
    useEffect(() => {
      pqmMetrics[`heavy-pqm-${formId}`] = {
        renderTime,
        renderCount: renderCount.current,
        memoryUsed: memoryUsed > 0 ? memoryUsed : 0,
      };
    }, [data, formId, renderTime, memoryUsed]);

    return <section ref={ref}>Heavy PQM (Form {formId}): {data.name} (Array size: {largeArray.length})</section>;
  },
  (prevProps, nextProps) => prevProps.data.name === nextProps.data.name
);

// Компонент без PQM
const HeavyComponentStandard = memo(
  ({ data, formId }: { data: { name: string; email: string; password: string }; formId: number }) => {
    const renderCount = useRef(0);
    renderCount.current += 1;

    const start = performance.now();
    const largeArray = new Array(1000000).fill(Math.random());
    while (performance.now() - start < 5) {}
    const renderTime = performance.now() - start;
    const memoryUsed = isMemoryAvailable ? performance.memory!.usedJSHeapSize / 1024 / 1024 : 0;

    useEffect(() => {
      standardMetrics[`heavy-standard-${formId}`] = {
        renderTime,
        renderCount: renderCount.current,
        memoryUsed: memoryUsed > 0 ? memoryUsed : 0,
      };
    }, [data, formId]);

    return <section>Heavy Standard (Form {formId}): {data.name} (Array size: {largeArray.length})</section>;
  },
  (prevProps, nextProps) => prevProps.data.name === nextProps.data.name
);

// Низкоприоритетный компонент с PQM
const LowPriorityComponentPQM = memo(
  ({ data, formId }: { data: { name: string; email: string; password: string }; formId: number }) => {
    const ref = usePQMComponent(`low-pqm-${formId}`, 80, () => {
      console.log(`Rendering LowPriorityComponentPQM for Form ${formId} with data: ${JSON.stringify(data)}`);
    });

    const start = performance.now();
    const smallArray = new Array(500000).fill(Math.random());
    while (performance.now() - start < 2) {}
    return <section ref={ref}>Low Priority PQM (Form {formId}): {data.email} (Array size: {smallArray.length})</section>;
  },
  (prevProps, nextProps) => prevProps.data.email === nextProps.data.email
);

// Низкоприоритетный компонент без PQM
const LowPriorityComponentStandard = memo(
  ({ data, formId }: { data: { name: string; email: string; password: string }; formId: number }) => {
    const renderCount = useRef(0);
    renderCount.current += 1;

    const start = performance.now();
    const smallArray = new Array(500000).fill(Math.random());
    while (performance.now() - start < 2) {}
    const renderTime = performance.now() - start;
    const memoryUsed = isMemoryAvailable ? performance.memory!.usedJSHeapSize / 1024 / 1024 : 0;

    useEffect(() => {
      standardMetrics[`low-standard-${formId}`] = {
        renderTime,
        renderCount: renderCount.current,
        memoryUsed: memoryUsed > 0 ? memoryUsed : 0,
      };
    }, [data, formId]);

    return <section>Low Priority Standard (Form {formId}): {data.email} (Array size: {smallArray.length})</section>;
  },
  (prevProps, nextProps) => prevProps.data.email === nextProps.data.email
);

function AppWithManyForms() {
  const [formsData, setFormsData] = useState<Record<number, { name: string; email: string; password: string }>>(
    Array.from({ length: 100 }, (_, i) => i).reduce((acc, id) => {
      acc[id] = { name: '', email: '', password: '' };
      return acc;
    }, {} as Record<number, { name: string; email: string; password: string }>)
  );

  const handleSubmit = (data: { name: string; email: string; password: string }, id: number) => {
    setFormsData((prev) => ({
      ...prev,
      [id]: data,
    }));
  };

  useEffect(() => {
    logMetrics('MB');
    console.log('HeavyComponentStandard Metrics:', standardMetrics);
    console.log('HeavyComponent with PQM Metrics:', pqmMetrics);
  }, [formsData]);

  return (
    <div>
      <h1>Multiple Forms Test (50 Forms)</h1>
      {Array.from({ length: 50 }, (_, i) => (
        <div key={i}>
          <RegistrationForm id={i} onSubmit={handleSubmit} />
          <HeavyComponentPQM data={formsData[i]} formId={i} />
          <HeavyComponentStandard data={formsData[i]} formId={i} />
          <LowPriorityComponentPQM data={formsData[i]} formId={i} />
          <LowPriorityComponentStandard data={formsData[i]} formId={i} />
        </div>
      ))}
    </div>
  );
}

export default AppWithManyForms;