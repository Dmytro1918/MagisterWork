// src/pqm.ts
import { useEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom';

// Тип для задачи
type ComponentTask = {
  id: string;
  priority: number;
  callback: () => void;
  visible: boolean;
  timestamp?: number;
  renderCount: number;
};

// Единицы измерения памяти
type MemoryUnit = 'MB' | 'KB' | 'Bytes';

// Интерфейс для метрик
interface Metrics {
  renderTime: number; // Время рендера (мс)
  renderCount: number; // Количество ререндерингов
  memoryUsed: number; // Использованная память в выбранных единицах
  queueProcessingTime?: number; // Время обработки очереди (мс)
}

// Хранилище метрик
const metricsStore: Record<string, Metrics> = {};

// Проверка доступности performance.memory
const isMemoryAvailable = !!performance.memory;

class PriorityQueue {
  private tasks: ComponentTask[] = [];

  enqueue(task: ComponentTask) {
    task.timestamp = Date.now();
    task.renderCount = (metricsStore[task.id]?.renderCount || 0) + 1;
    this.tasks.push(task);
    this.tasks.sort((a, b) => a.priority - b.priority);
    this.notifyDevTools();
  }

  dequeue(): ComponentTask | undefined {
    return this.tasks.shift();
  }

  isEmpty(): boolean {
    return this.tasks.length === 0;
  }

  getTasks(): ComponentTask[] {
    return [...this.tasks];
  }

  private notifyDevTools() {
    if ((window as any).__REACT_DEVTOOLS_GLOBAL_HOOK__) {
      const tasks = this.getTasks().map((task) => ({
        id: task.id,
        priority: task.priority,
        visible: task.visible,
        status: 'queued' as const,
        renderCount: task.renderCount,
      }));
      (window as any).__REACT_DEVTOOLS_GLOBAL_HOOK__.emit('pqm:queueUpdate', tasks);
    }
  }
}

class PQM {
  private queue = new PriorityQueue();
  private isProcessing = false;

  addTask(id: string, priority: number, callback: () => void, visible: boolean) {
    this.queue.enqueue({ id, priority, callback, visible, renderCount: 0 });
    this.processQueue();
  }

  private async processQueue() {
    if (this.isProcessing) return;
    this.isProcessing = true;

    const queueStartTime = performance.now();

    while (!this.queue.isEmpty()) {
      const task = this.queue.dequeue();
      if (task && (task.visible || task.priority <= 50)) {
        this.notifyDevTools(task.id, 'rendering');
        const startTime = performance.now();
        task.callback();
        const renderTime = performance.now() - startTime;
        const memoryUsedBytes = isMemoryAvailable ? performance.memory!.usedJSHeapSize : 0;
        const memoryUsed = this.convertMemoryUnits(memoryUsedBytes, 'MB'); // Общее потребление

        // Отладка
        // console.log(`[PQM Debug] ${task.id} - Memory Used: ${memoryUsedBytes} Bytes`);

        // Сохраняем метрики
        metricsStore[task.id] = {
          renderTime,
          renderCount: task.renderCount,
          memoryUsed: memoryUsed > 0 ? memoryUsed : 0,
        };

        this.notifyDevTools(task.id, 'completed', renderTime);
        await new Promise((resolve) => requestAnimationFrame(resolve));
      }
    }

    const queueProcessingTime = performance.now() - queueStartTime;
    console.log('[PQM Metrics] Queue Processing Time:', queueProcessingTime, 'ms');
    this.isProcessing = false;
  }

  private convertMemoryUnits(bytes: number, unit: MemoryUnit): number {
    switch (unit) {
      case 'MB':
        return bytes / 1024 / 1024;
      case 'KB':
        return bytes / 1024;
      case 'Bytes':
        return bytes;
      default:
        return bytes / 1024 / 1024;
    }
  }

  private notifyDevTools(id: string, status: 'rendering' | 'completed', renderTime?: number) {
    if ((window as any).__REACT_DEVTOOLS_GLOBAL_HOOK__) {
      const task = this.queue.getTasks().find((t) => t.id === id) || {
        id,
        priority: 0,
        visible: false,
        renderCount: metricsStore[id]?.renderCount || 0,
      };
      const data = {
        id,
        priority: task.priority,
        visible: task.visible,
        status,
        renderCount: task.renderCount,
        renderTime,
        memoryUsed: metricsStore[id]?.memoryUsed || 0,
      };
      (window as any).__REACT_DEVTOOLS_GLOBAL_HOOK__.emit('pqm:taskUpdate', data);
    }
  }

  getMetrics(): Record<string, Metrics> {
    return { ...metricsStore };
  }
}

export const pqm = new PQM();

export function useViewportObserver(ref: React.RefObject<HTMLElement | null>) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setIsVisible(entry.isIntersecting),
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [ref]);

  return isVisible;
}

export function usePQMComponent(id: string, priority: number, renderFn: () => void) {
  const ref = useRef<HTMLElement>(null);
  const isVisible = useViewportObserver(ref);

  useEffect(() => {
    pqm.addTask(id, priority, () => {
      if (ref.current) {
        ReactDOM.unstable_batchedUpdates(() => renderFn());
      }
    }, isVisible);
  }, [id, priority, isVisible, renderFn]);

  return ref;
}

export function logMetrics(unit: MemoryUnit = 'MB') {
  const metrics = pqm.getMetrics();
  console.log(`[PQM Metrics (${unit})]`, metrics);
  if (!isMemoryAvailable) {
    console.warn('[PQM Warning] performance.memory is not available in this browser');
  }
}